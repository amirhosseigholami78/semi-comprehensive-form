const password = document.getElementById('password')
const errorElement = document.getElementById('error')
const form = document.getElementById('form')
const showPassword = document.getElementById('show-password')
var loader = document.querySelector(".loader")

window.addEventListener("load", vanish)
function vanish(){
    loader.classList.add("disappear")
}



form.addEventListener('submit', (e)=>{
    let messages = []

    if(password.value.length <=6){
        messages.push('password must be longer than 6 items' )
    }
    if(password.value.length>20){
        messages.push('password must be less than 20 items')
    }
    if(password.value === 'password'){
        messages.push('password can not be the password ')
    }
    if(messages.length > 0){
        e.preventDefault()
        errorElement.innerText = messages.join(',')
    }
})

showPassword.addEventListener("click", function(){
    this.classList.toggle("icon-eye-blocked")
    const type = password.getAttribute("type")
    === "password" ? "text" : "password";
    password.setAttribute("type", type)
})
    // by this part user in not allowed to enter persian character and if we set x !=1, nothing (neither persian nor English character) is going to show up in the input
document.getElementById('txt').addEventListener('input', function(){
       let  temp = this.value
        x = temp.search(/[ا-ی]/)
        if(x !=-1){
            this.value = temp.substring(0, (temp.length)-1)
        }
    })





